from django.contrib import admin
from comida_app.models import Petisco

# Register your models here.
admin.site.register(Petisco)