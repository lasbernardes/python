from datetime import datetime

class Residente:
    def __init__(self, identificador, idade, formacao, formacaoGeral , formacaoEspecifica, andamentoGraduacao, tempoFormacao, experienciaPrevia ):
        self.identificador = identificador
        self.idade = idade
        self.formacao = formacao
        self.formacao_geral = formacaoGeral
        self.formacao_especifica = formacaoEspecifica
        self.andamento_graduacao = andamentoGraduacao
        self.tempo_formacao = tempoFormacao
        self.experiencia_previa = experienciaPrevia
    #def end

    def __str__(self):
        return f'Residente - Identificador: {self.identificador}, Idade: {self.idade}, Formação: {self.formacao}, Formação Geral: {self.formacao_geral}, Formação Específica: {self.formacao_especifica}, Andamento Graduação: {self.andamento_graduacao}, Tempo Formação: {self.tempo_formacao}, Experiência Prévia: {self.experiencia_previa}'

    def __repr__(self):
        return f'Residente({self.nome}, {self.idade}, {self.sexo}, {self.cpf})'
    
    @staticmethod
    def checkTrilha(trilha,checkTrilha):
        while trilha not in checkTrilha:
                print(f"Trilhas aceitas: {checkTrilha}.")
                trilha = input("Trilha: ")
        #end
        if trilha == 'Python':
            return trilha[:2]
        else:
            return trilha[:3].capitalize()
    #def end

    @staticmethod
    def checkCPF(cpf):
        while int(len(cpf)) != 3:
             cpf = input('Digite 3 primeiros número do seu CPF: ')
        #while end
        return cpf
    #def end

    @staticmethod
    def apuraIdade(nasc):
        while not nasc.isdigit() or int(len(nasc)) != 4:
            nasc = input("Digite ano de nascimento: ")
        #while end
        nasc = str(datetime.now().year - int(nasc))
        return nasc
    #def end

    def cadastraUm(self):
        print("Cadastra um residente")
        listCheckTrilha = ['py', 'Py', 'Python', 'python', 'net', 'Net', 'jav','Jav','Java','java']
        print(f"Trilhas aceitas: {listCheckTrilha}.")
        trilha = Residente.checkTrilha(input("Trilha: "), listCheckTrilha) #input("Trilha: ")
        cpf = Residente.checkCPF(input('Digite 3 primeiros número do seu CPF: '))
        idade = Residente.apuraIdade(input("Digite ano de nascimento: "))
        self.identificador = 'Tic18'+trilha+cpf+idade
        self.nome = input("Nome: ")
    #def end
    
   

#class end
#cadastraUm('t')

residente = Residente(identificador=1, idade=25, formacao="Engenharia", formacaoGeral="Bacharelado",
                      formacaoEspecifica="Engenharia Mecânica", andamentoGraduacao=True,
                      tempoFormacao=4, experienciaPrevia="Estágio em uma empresa de engenharia")

residente.cadastraUm()

print(residente)
