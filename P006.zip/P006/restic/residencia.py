# File: residencia.py

class Residencia:
    def __init__(self, nome):
        self.nome = nome
        self.trilhas = []

    def adicionar_trilha(self, trilha):
        # Ensure unique trilha identifier and add it to the list
        pass
